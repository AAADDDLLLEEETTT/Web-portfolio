from app import db, Product

sample_products = [
    {
        "title": "Корм",
        "description": "Корм для щенков",
        "price": 10.99,
        "category": "Собаки",
        "image_url": "/static/img/products/dog1.jpg"
    },
    {
        "title": "Консервы",
        "description": "Консервы для щенков до 2-х месяцев",
        "price": 15.99,
        "category": "Собаки",
        "image_url": "/static/img/products/dog3.jpg"
    },
    {
        "title": "Лакомства",
        "description": "Лакомство для собак",
        "price": 20.99,
        "category": "Собаки",
        "image_url": "/static/img/products/dog4.jpg"
    }
]

# Добавление товаров в базу данных
for product_data in sample_products:
    product = Product(
        title=product_data["title"],
        description=product_data["description"],
        price=product_data["price"],
        category=product_data["category"],
        image_url=product_data["image_url"]
    )
    db.session.add(product)

db.session.commit()

print("Примерные товары успешно добавлены!")


# For Adding in console
# flask shell
# exec(open('sample.py', encoding='utf-8').read())